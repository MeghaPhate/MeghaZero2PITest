const express = require('express');
const con = require('../mysqlConnection/connection');
const router = express.Router();
const connection = require('../mysqlConnection/connection');
/**
 * Desc:Api call for Player info add into database;
 */
router.post('/playerList',function(req,resp){
    try{
        let playerName = req.body.playerName;
        let matchesPlayed = req.body.matchesPlayed;
        let noOfMatchesWon = req.body.noOfMatchesWon;
        let noOfMatchesLost = req.body.noOfMatchesLost;
        let sportName = req.body.sportName;
        let coachName = req.body.coachName;
         
                var sql = 'insert into PlayerDetails(playerName,matchesPlayed,noOfMatchesWon,noOfMatchesLost,sportName,coachName) values(?,?,?,?,?,?);';
                connection.query(sql, [playerName,matchesPlayed,noOfMatchesWon,noOfMatchesLost,sportName,coachName], function (err, result) {
                    if(err){
                   console.log(err);
                    }
                    else  
                    {
                    resp.send('player added successfully.....');
                    }
                })
   
    }catch(error){

    }
})
/**
 * Desc:Api call for get player List from  database based on name and sportName;
 */
router.get('/playerList/:playerName/:sportName',function(req,resp){
    try{
        let playerName = req.params.playerName;
        let sportName = req.params.sportName;
        var sql = 'select * from PlayerDetails where playerName = ? and sportName = ? ;';
    connection.query(sql,[playerName,sportName], function (err, result) {
        if (err) {
           console.log(err);
            }
        else{
            resp.send(result);
        }
        })
        
    }catch(error){

    }
})
/**
 * Desc:Api call for serach most efficient player is shown on top based on sportName;
 */
router.get('/playerList/Search/efficientPlayer/:sportName',function(req,resp){
    try{
        let sportName = req.params.sportName;
        var sql = 'select * from PlayerDetails where sportName = ? ;';
        var response;
    connection.query(sql,[sportName], function (err, result) {
        if (err) {
           console.log(err);
            }
        else{
            if(result.length>0){
                response = result;
                for(let i=0;i<response.length;i++){
                    let output = response[i].noOfMatchesWon;
                    let input = response[i].matchesPlayed;
                    let efficientPlayer = (output/input)*100;
                    response[i].efficiency = efficientPlayer;
                    response.sort(function(a, b){
                    return b.efficiency - a.efficiency;
               });
                }
              resp.send(response);
            }
           
        }
        })
        
    }catch(error){

    }
})
/**
 * Desc:Api call for get all player List from  database;
 */
 router.get('/playerList',function(req,resp){
    try{
        var sql = 'select * from PlayerDetails;';
    connection.query(sql, function (err, result) {
        if (err) {
           console.log(err);
            }
        else{
            resp.send(result);
        }
        })
        
    }catch(error){

    }
})
module.exports = router;