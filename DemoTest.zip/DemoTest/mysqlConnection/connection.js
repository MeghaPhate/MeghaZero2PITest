var mysql = require('mysql');


var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password",
    database: 'demo',
    insecureAuth : true
});

con.connect(function(err) {
  if (err) throw err;
  else
  //return true;
 console.log("Connected!");
});
module.exports = con;