//Load HTTP module
const http = require("http");
const express = require('express');
path = require('path');
const app = express();
var bodyParser = require('body-parser');
const player = require('./ApiCalls/playerList');
var fileupload = require("express-fileupload");
app.use(express.static(path.join(__dirname, 'image')));
app.use(fileupload());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(player);

//listen for request on port 3000, and as a callback function have the port listened on logged
app.listen(3000,() => {
  console.log(`Server running on port 3000`);
});